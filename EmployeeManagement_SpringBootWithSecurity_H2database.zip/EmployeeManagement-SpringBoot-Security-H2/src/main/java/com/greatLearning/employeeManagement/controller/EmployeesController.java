package com.greatLearning.employeeManagement.controller;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.greatLearning.employeeManagement.entity.Employee;
import com.greatLearning.employeeManagement.service.EmployeeService;

//controller class for processing incoming REST API requests
@Controller
@RequestMapping("/api/employees")
public class EmployeesController {

	// Enables automatic dependency injection for employeeservice class
	@Autowired
	private EmployeeService employeeService;

	// mapping to find the list of employees under /employees/list
	@RequestMapping("/list")
	public String listEmployees(Model theModel) {
		List<Employee> theEmployees = employeeService.findAll();
		theModel.addAttribute("Employees", theEmployees);
		return "list-Employees";
	}

	/*
	 * @RequestMapping("/getById") public String
	 * getAEmployeeById(@RequestParam("employeeId") int theId, Model theModel) {
	 * Employee employee= employeeService.getAEmployeeById(theId);
	 * theModel.addAttribute("Employees", employee); return "list-Employees"; }
	 */ // for adding employee details
	@RequestMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		Employee theEmployee = new Employee();
		// create model attribute to bind form data
		theModel.addAttribute("Employee", theEmployee);
		return "Employee-form";
	}

	// To update specific existing employee details
	@RequestMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("employeeId") int theId, Model theModel) {
		// get the Employee from the service
		Employee theEmployee = employeeService.findById(theId);
		// set employee as a model attribute to pre-populate the form
		theModel.addAttribute("Employee", theEmployee);
		// send over to our form
		return "Employee-form";
	}

	// save the data in the database and redirect to list of employees page
	@PostMapping("/save")
	public String saveEmployee(@RequestParam("id") int id, @RequestParam("firstName") String firstName,
			@RequestParam("lastName") String lastName, @RequestParam("email") String email) {

		System.out.println(id);
		Employee theEmployee;
		if (id != 0) {
			theEmployee = employeeService.findById(id);
			theEmployee.setfirstName(firstName);
			theEmployee.setlastName(lastName);
			theEmployee.setEmail(email);
		} else
			theEmployee = new Employee(firstName, lastName, email);
		// save the employee
		employeeService.save(theEmployee);
		// use a redirect to prevent duplicate submissions
		return "redirect:/api/employees/list";
	}

	@RequestMapping("/delete")
	public String delete(@RequestParam("employeeId") int theId) {
		// delete the employee
		employeeService.deleteById(theId);
		// redirect to /employees/list
		return "redirect:/api/employees/list";
	}

	@RequestMapping("/search")
	public String search(@RequestParam("firstName") String firstName, Model theModel) {

		// search for firstName, then just give list of all employees that matches

		if (firstName.trim().isEmpty()) {
			return "redirect:/api/employees/list";
		} else {
			// else, search by first name and last name
			List<Employee> theEmployees = employeeService.searchBy(firstName);

			// add to the spring model
			theModel.addAttribute("Employees", theEmployees);

			// send to list-Employees
			return "list-Employees";
		}
	}

	@RequestMapping("/searchid")
	public String getAEmployeeById(@RequestParam("id") int id, Model theModel) {

		Employee theEmployee = employeeService.findById(id);
		// set employee as a model attribute to pre-populate the form
		theModel.addAttribute("Employee", theEmployee);
		// send to search-Employee
		return "search-Employee";
	}

	@RequestMapping("/sort/asc")
	public String sortAsc(Model theModel) {
		// sort employees by ascending order
		List<Employee> theEmployees = employeeService.sortByAsc();

		// add to the spring model
		theModel.addAttribute("Employees", theEmployees);

		// send to list-Employees
		return "list-Employees";
	}

	@RequestMapping("/sort/desc")
	public String sortDesc(Model theModel) {

		// sort employees by descending order
		List<Employee> theEmployees = employeeService.sortByDesc();

		// add to the spring model
		theModel.addAttribute("Employees", theEmployees);

		// send to list-Books
		return "list-Employees";
	}

	// Display the msg if user is not authorized to create/update/delete/view data
	@RequestMapping(value = "/403")
	public ModelAndView accesssDenied(Principal user) {

		ModelAndView model = new ModelAndView();
		if (user != null) {
			model.addObject("msg", "Hi " + user.getName() + ", you do not have permission to access this page!");
		} else {
			model.addObject("msg", "You do not have permission to access this page!");

		}
		model.setViewName("403");
		return model;
	}
}
