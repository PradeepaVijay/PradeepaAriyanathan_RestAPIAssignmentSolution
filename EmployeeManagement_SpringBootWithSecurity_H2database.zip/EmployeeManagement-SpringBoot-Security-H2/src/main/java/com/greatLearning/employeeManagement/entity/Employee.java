package com.greatLearning.employeeManagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

//Employee class is an entity and is mapped to a database table employee
@Entity
public class Employee {
	// Field id is mapped as primary key

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	// Field firstName, lastName,email are mapped to column
	// employee table
	private String firstName;
	private String lastName;
	private String email;

	public Employee() {
	}

	public Employee(String firstName, String lastName, String email) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}

	// Setters and Getters for all the fields
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getfirstName() {
		return firstName;
	}

	public void setfirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getlastName() {
		return lastName;
	}

	public void setlastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
