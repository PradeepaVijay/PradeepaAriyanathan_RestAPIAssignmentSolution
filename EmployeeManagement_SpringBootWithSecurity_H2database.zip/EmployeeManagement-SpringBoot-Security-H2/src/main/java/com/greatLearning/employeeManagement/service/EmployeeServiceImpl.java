package com.greatLearning.employeeManagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.greatLearning.employeeManagement.entity.Employee;
import com.greatLearning.employeeManagement.repository.EmployeeRepository;

//Define service implementation class for business logic
@Service
public class EmployeeServiceImpl implements EmployeeService {

	// Dependency injection for EmployeeRepository,use and override JPA methods
	@Autowired
	EmployeeRepository employeeRepository;

	//Get all the employees
	@Override
	public List<Employee> findAll() {
		List<Employee> employees = employeeRepository.findAll();
		return employees;
	}

	//Get specific employee by using Id
	@Override
	public Employee findById(int theId) {
		// TODO Auto-generated method stub
		return employeeRepository.findById(theId).get();
	}

	//
	@Override
	public void save(Employee theEmployee) {
		// TODO Auto-generated method stub
		employeeRepository.save(theEmployee);

	}
	
	@Override
	public void deleteById(int theId) {
		// TODO Auto-generated method stub
		employeeRepository.deleteById(theId);

	}

	@Override
	public List<Employee> searchBy(String firstName) {
		// TODO Auto-generated method stub
		// employeeRepository.findAll(example);
		Employee employee = new Employee();
		employee.setfirstName(firstName);
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withMatcher("firstName", ExampleMatcher.GenericPropertyMatchers.exact())
				.withIgnorePaths("lastName", "email", "id");
		Example<Employee> example = Example.of(employee, exampleMatcher);
		return employeeRepository.findAll(example);
	}

	@Override
	public List<Employee> sortByAsc() {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		// employee.setfirstName(firstName);
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withMatcher("firstName", ExampleMatcher.GenericPropertyMatchers.exact())
				.withIgnorePaths("lastName", "email", "id");
		Example<Employee> example = Example.of(employee, exampleMatcher);
		return employeeRepository.findAll(Sort.by(Direction.ASC, "firstName"));
	}

	@Override
	public List<Employee> sortByDesc() {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		// employee.setfirstName(firstName);
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withMatcher("firstName", ExampleMatcher.GenericPropertyMatchers.exact())
				.withIgnorePaths("lastName", "email", "id");
		Example<Employee> example = Example.of(employee, exampleMatcher);
		return employeeRepository.findAll(Sort.by(Direction.DESC, "firstName"));
	}

}