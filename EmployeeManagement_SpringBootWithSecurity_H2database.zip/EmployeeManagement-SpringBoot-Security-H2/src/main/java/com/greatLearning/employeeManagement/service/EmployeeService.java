package com.greatLearning.employeeManagement.service;

import java.util.List;
import java.util.Optional;

import com.greatLearning.employeeManagement.entity.Employee;

//Interface for service class  with  abstract methods
public interface EmployeeService {
	public List<Employee> findAll();

	public Employee findById(int theId);

	public void save(Employee theEmployee);

	public void deleteById(int theId);

	public List<Employee> searchBy(String firstName);

	public List<Employee> sortByAsc();

	public List<Employee> sortByDesc();

}