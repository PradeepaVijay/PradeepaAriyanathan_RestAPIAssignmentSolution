insert into users(username, password) values ('pradeepa', '$2a$12$EyK.sI8hckz/caVyuMNrneboQQSXje2MbRt1qfVeYU1NKcJrI6yl.');
insert into users(username, password) values ('vijay', '$2a$12$y5t6B4nXYnEgtn7p6VN3buEOl.tc85E/.J./z0YNXIIVo09/yPVtC');
insert into roles(name) values ('USER'); 
insert into roles(name) values ('ADMIN');
insert into users_roles values (1, 2);
insert into users_roles values (2, 1);